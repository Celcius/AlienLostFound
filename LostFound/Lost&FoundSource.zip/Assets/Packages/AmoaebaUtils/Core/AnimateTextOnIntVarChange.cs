﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AmoaebaUtils
{
public class AnimateTextOnIntVarChange : AnimateTextOnChange<IntVar, int> {}
}