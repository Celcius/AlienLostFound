using UnityEngine;
using System;
using System.Collections;


// !!!!! WARNING !!!!!
// Auto Generated Class --- DO NOT CHANGE ---


namespace Config {
public class Test1Entry : ScriptableObject {
 

public string nameVal;


public float attackVal;


public int healthVal;

 }
}
