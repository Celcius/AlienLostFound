﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AmoaebaUtils
{
public class RegisterRigidbody2D : RegisterComponentVar<Rigidbody2D, Rigidbody2DVar> {}
}