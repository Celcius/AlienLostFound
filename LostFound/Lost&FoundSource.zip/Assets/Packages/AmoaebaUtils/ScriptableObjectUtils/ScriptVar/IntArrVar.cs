﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AmoaebaUtils
{
public class IntArrVar : ArrayVar<int>
{
}
}