﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AmoaebaUtils;

namespace AmoaebaUtils
{
public class RegisterAnimatorVar : RegisterComponentVar<Animator, AnimatorVar> {}
}