﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Parallaxable : MonoBehaviour
{
    public abstract Bounds GetBounds();
}
