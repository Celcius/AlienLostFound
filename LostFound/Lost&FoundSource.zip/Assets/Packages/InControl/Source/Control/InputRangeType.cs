﻿namespace InControl
{
	public enum InputRangeType : int
	{
		// TODO: Can None be removed?
		None = 0,
		MinusOneToOne,
		OneToMinusOne,
		ZeroToOne,
		ZeroToMinusOne,
		OneToZero,
		MinusOneToZero,
	}
}
