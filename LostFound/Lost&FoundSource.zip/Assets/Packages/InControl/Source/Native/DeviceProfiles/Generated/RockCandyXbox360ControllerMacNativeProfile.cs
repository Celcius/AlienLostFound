// ReSharper disable StringLiteralTypo
// ReSharper disable IdentifierTypo
// ReSharper disable InconsistentNaming
// ReSharper disable UnusedType.Global
namespace InControl.NativeDeviceProfiles
{
	// @cond nodoc
	[Preserve, NativeInputDeviceProfile]
	public class RockCandyXbox360ControllerMacNativeProfile : Xbox360DriverMacNativeProfile
	{
		public override void Define()
		{
			base.Define();

			DeviceName = "Rock Candy Xbox 360 Controller";
			DeviceNotes = "Rock Candy Xbox 360 Controller on Mac";

			Matchers = new[]
			{
				new InputDeviceMatcher
				{
					VendorID = 0x0e6f,
					ProductID = 0x021f,
				},
				new InputDeviceMatcher
				{
					VendorID = 0x24c6,
					ProductID = 0xfafe,
				},
				new InputDeviceMatcher
				{
					VendorID = 0x0e6f,
					ProductID = 0x0152,
				},
			};
		}
	}

	// @endcond
}
