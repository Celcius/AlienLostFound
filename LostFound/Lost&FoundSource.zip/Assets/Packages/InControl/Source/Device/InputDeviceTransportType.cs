﻿// ReSharper disable InconsistentNaming
namespace InControl
{
	using UnityEngine;

	public enum InputDeviceTransportType : ushort
	{
		Unknown,
		USB,
		Bluetooth,
	}
}
