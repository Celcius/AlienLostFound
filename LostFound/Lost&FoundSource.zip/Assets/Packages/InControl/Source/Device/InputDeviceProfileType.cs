namespace InControl
{
	public enum InputDeviceProfileType
	{
		Unity,
		Native
	}
}
